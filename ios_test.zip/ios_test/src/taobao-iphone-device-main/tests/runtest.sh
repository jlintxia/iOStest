#!/bin/bash
#

python3 -m tidevice install -h